package com.nextcare.claimcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
